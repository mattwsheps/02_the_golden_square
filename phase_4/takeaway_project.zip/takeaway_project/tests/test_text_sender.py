from lib.text_sender import *

